/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

pref("startup.homepage_override_url", "");
pref("startup.homepage_welcome_url", "");
pref("startup.homepage_welcome_url.additional", "");
pref("tern.autohide.tabs", true);
pref("tern.autohide.navbar", true);
pref("extensions.activeThemeID", "auratern-theme-auto@auralinux.org");
